
def test_generic():
    a=2
    b=2
    ## comparing the values
    assert a==b